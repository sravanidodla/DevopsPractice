## Remote State - Backend S3

Storing the terraform remote state in AWS S3 as backend

Using the remote store for the terraform state will ensure that you always have the latest version of the state.

First thing you need to do is -
	1. go to AWS S3 and create new bucket. Give any name and region in which you want to create it
	2. then create a new file named backend.tf
